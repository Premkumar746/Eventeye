import { Card } from "@/components/ui/card";
import { Award } from "lucide-react";

interface CertificatePreviewProps {
  participantName?: string;
  eventName?: string;
  eventDate?: string;
  organizerName?: string;
  includeQR?: boolean;
}

export function CertificatePreview({
  participantName = "Participant Name",
  eventName = "Event Name",
  eventDate = "January 15, 2025",
  organizerName = "Organizer Name",
  includeQR = true,
}: CertificatePreviewProps) {
  return (
    <Card className="p-12 bg-gradient-to-br from-background to-muted/20 border-2" data-testid="card-certificate-preview">
      <div className="aspect-[1.414/1] flex flex-col items-center justify-center text-center space-y-8 border-4 border-primary/20 rounded-md p-8">
        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
          <Award className="w-10 h-10 text-primary" />
        </div>
        
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
            Certificate of Participation
          </h3>
          <h1 className="text-4xl font-bold text-foreground">
            {participantName}
          </h1>
        </div>

        <div className="space-y-4 max-w-md">
          <p className="text-muted-foreground">
            has successfully participated in
          </p>
          <h2 className="text-2xl font-semibold text-foreground">
            {eventName}
          </h2>
          <p className="text-sm text-muted-foreground">
            held on {eventDate}
          </p>
        </div>

        <div className="flex items-center justify-between w-full mt-8 pt-8 border-t">
          <div className="text-left">
            <p className="text-xs text-muted-foreground mb-1">Organizer</p>
            <p className="font-medium text-sm">{organizerName}</p>
          </div>
          {includeQR && (
            <div className="w-20 h-20 bg-muted/50 rounded flex items-center justify-center">
              <div className="w-16 h-16 bg-foreground/10 rounded grid grid-cols-4 gap-[2px] p-1">
                {Array.from({ length: 16 }).map((_, i) => (
                  <div
                    key={i}
                    className={`rounded-sm ${
                      Math.random() > 0.5 ? "bg-foreground" : "bg-transparent"
                    }`}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
