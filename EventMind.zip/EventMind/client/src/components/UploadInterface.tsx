import { useState, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, FileSpreadsheet, Download, X } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface UploadInterfaceProps {
  onFileSelect?: (file: File) => void;
  onUploadComplete?: () => void;
}

export function UploadInterface({ onFileSelect, onUploadComplete }: UploadInterfaceProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file && (file.name.endsWith('.csv') || file.name.endsWith('.xlsx'))) {
      setSelectedFile(file);
      onFileSelect?.(file);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      onFileSelect?.(file);
    }
  };

  const handleUpload = () => {
    if (!selectedFile) return;
    
    setIsUploading(true);
    setUploadProgress(0);
    
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setIsUploading(false);
            onUploadComplete?.();
          }, 500);
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  const handleClear = () => {
    setSelectedFile(null);
    setUploadProgress(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <Card className="p-8" data-testid="card-upload-interface">
      <div className="space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-lg font-semibold mb-2">Upload Participants</h3>
            <p className="text-sm text-muted-foreground">
              Import participant data from CSV or Excel files
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => console.log("Download template")}
            data-testid="button-download-template"
          >
            <Download className="w-4 h-4 mr-2" />
            Template
          </Button>
        </div>

        {!selectedFile ? (
          <div
            className={`border-2 border-dashed rounded-md p-12 text-center transition-colors cursor-pointer ${
              isDragging
                ? "border-primary bg-primary/5"
                : "border-border hover:border-primary/50 hover-elevate"
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            data-testid="dropzone-upload"
          >
            <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-sm font-medium mb-2">
              Drop your file here or click to browse
            </p>
            <p className="text-xs text-muted-foreground">
              Supports CSV and Excel files (max 10MB)
            </p>
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.xlsx,.xls"
              className="hidden"
              onChange={handleFileSelect}
              data-testid="input-file"
            />
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-4 border rounded-md">
              <FileSpreadsheet className="w-8 h-8 text-primary" />
              <div className="flex-1">
                <p className="font-medium text-sm">{selectedFile.name}</p>
                <p className="text-xs text-muted-foreground">
                  {(selectedFile.size / 1024).toFixed(2)} KB
                </p>
              </div>
              {!isUploading && (
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={handleClear}
                  data-testid="button-clear-file"
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>

            {isUploading && (
              <div className="space-y-2">
                <Progress value={uploadProgress} />
                <p className="text-xs text-center text-muted-foreground">
                  Uploading... {uploadProgress}%
                </p>
              </div>
            )}

            {!isUploading && uploadProgress < 100 && (
              <div className="flex gap-2">
                <Button
                  className="flex-1"
                  onClick={handleUpload}
                  data-testid="button-upload"
                >
                  Upload & Process
                </Button>
                <Button
                  variant="outline"
                  onClick={handleClear}
                  data-testid="button-cancel-upload"
                >
                  Cancel
                </Button>
              </div>
            )}
          </div>
        )}

        <div className="bg-muted/30 p-4 rounded-md space-y-2">
          <p className="text-xs font-medium">Required columns:</p>
          <div className="flex flex-wrap gap-2">
            {["Name", "Email", "Phone (optional)"].map((col) => (
              <Badge key={col} variant="outline" className="text-xs font-mono">
                {col}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}

function Badge({ children, variant, className }: { children: React.ReactNode; variant?: string; className?: string }) {
  return (
    <span className={`inline-flex items-center px-2 py-1 text-xs rounded-md border ${className}`}>
      {children}
    </span>
  );
}
