import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { StatusBadge, DeliveryStatus } from "./StatusBadge";
import { Search, Send, RefreshCw, Trash2, Edit2 } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export interface Participant {
  id: string;
  name: string;
  email: string;
  phone?: string;
  status: DeliveryStatus;
  sentDate?: string;
  aiConfidence?: number;
}

interface ParticipantTableProps {
  participants: Participant[];
  onSendBulk?: (selectedIds: string[]) => void;
  onResend?: (id: string) => void;
  onDelete?: (selectedIds: string[]) => void;
}

export function ParticipantTable({ participants, onSendBulk, onResend, onDelete }: ParticipantTableProps) {
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState("");

  const filteredParticipants = participants.filter((p) =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleSelect = (id: string) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredParticipants.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredParticipants.map((p) => p.id)));
    }
  };

  const getConfidenceColor = (confidence?: number) => {
    if (!confidence) return "text-muted-foreground";
    if (confidence >= 90) return "text-chart-2";
    if (confidence >= 70) return "text-chart-5";
    return "text-destructive";
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search participants..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-participants"
          />
        </div>
        {selectedIds.size > 0 && (
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">
              {selectedIds.size} selected
            </span>
            <Button
              size="sm"
              onClick={() => onSendBulk?.(Array.from(selectedIds))}
              data-testid="button-send-bulk"
            >
              <Send className="w-4 h-4 mr-2" />
              Send
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => onDelete?.(Array.from(selectedIds))}
              data-testid="button-delete-bulk"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete
            </Button>
          </div>
        )}
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12">
                <Checkbox
                  checked={selectedIds.size === filteredParticipants.length && filteredParticipants.length > 0}
                  onCheckedChange={toggleSelectAll}
                  data-testid="checkbox-select-all"
                />
              </TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>AI Score</TableHead>
              <TableHead>Sent Date</TableHead>
              <TableHead className="w-24">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredParticipants.map((participant) => (
              <TableRow key={participant.id} data-testid={`row-participant-${participant.id}`}>
                <TableCell>
                  <Checkbox
                    checked={selectedIds.has(participant.id)}
                    onCheckedChange={() => toggleSelect(participant.id)}
                    data-testid={`checkbox-participant-${participant.id}`}
                  />
                </TableCell>
                <TableCell className="font-medium">{participant.name}</TableCell>
                <TableCell className="text-sm text-muted-foreground">{participant.email}</TableCell>
                <TableCell className="text-sm text-muted-foreground">{participant.phone || "—"}</TableCell>
                <TableCell>
                  <StatusBadge status={participant.status} />
                </TableCell>
                <TableCell>
                  {participant.aiConfidence ? (
                    <span className={`text-sm font-mono font-medium ${getConfidenceColor(participant.aiConfidence)}`}>
                      {participant.aiConfidence}%
                    </span>
                  ) : (
                    <span className="text-sm text-muted-foreground">—</span>
                  )}
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">
                  {participant.sentDate || "—"}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => onResend?.(participant.id)}
                      data-testid={`button-resend-${participant.id}`}
                    >
                      <RefreshCw className="w-4 h-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      data-testid={`button-edit-${participant.id}`}
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
