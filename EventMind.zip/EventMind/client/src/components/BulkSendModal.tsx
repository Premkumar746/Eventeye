import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Mail, MessageSquare, Clock, CheckCircle } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface BulkSendModalProps {
  eventId: string;
  onClose: () => void;
}

export function BulkSendModal({ eventId, onClose }: BulkSendModalProps) {
  const [step, setStep] = useState<"select" | "sending" | "complete">("select");
  const [channels, setChannels] = useState({
    email: true,
    whatsapp: false,
  });
  const [progress, setProgress] = useState(0);
  const { toast } = useToast();

  const { data: participants } = useQuery({
    queryKey: ["/api/events", eventId, "participants"],
  });

  const participantCount = participants?.length || 0;
  const participantIds = participants?.map((p: any) => p.id) || [];

  const handleConfirm = async () => {
    const selectedChannels = Object.entries(channels)
      .filter(([_, enabled]) => enabled)
      .map(([channel]) => channel);

    setStep("sending");

    try {
      let currentProgress = 0;
      const interval = setInterval(() => {
        currentProgress += 20;
        setProgress(Math.min(currentProgress, 90));
      }, 300);

      await apiRequest("/api/participants/bulk-send", {
        method: "POST",
        body: JSON.stringify({
          participantIds,
          channels: selectedChannels,
        }),
        headers: { "Content-Type": "application/json" },
      });

      clearInterval(interval);
      setProgress(100);

      setTimeout(() => {
        setStep("complete");
        queryClient.invalidateQueries({ queryKey: ["/api/events"] });
        
        setTimeout(() => {
          onClose();
          setStep("select");
          setProgress(0);
        }, 1500);
      }, 500);
    } catch (error) {
      setStep("select");
      setProgress(0);
      toast({
        title: "Send failed",
        description: "Failed to send certificates",
        variant: "destructive",
      });
    }
  };

  const handleToggleChannel = (channel: "email" | "whatsapp") => {
    setChannels((prev) => ({ ...prev, [channel]: !prev[channel] }));
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent data-testid="modal-bulk-send">
        <DialogHeader>
          <DialogTitle>
            {step === "select" && "Send Certificates"}
            {step === "sending" && "Sending Certificates"}
            {step === "complete" && "Certificates Sent!"}
          </DialogTitle>
          <DialogDescription>
            {step === "select" && `Send certificates to ${participantCount} participants`}
            {step === "sending" && "Please wait while we process your certificates"}
            {step === "complete" && "All certificates have been sent successfully"}
          </DialogDescription>
        </DialogHeader>

        {step === "select" && (
          <div className="space-y-6 py-4">
            <div className="space-y-4">
              <div className="flex items-start gap-3 p-4 border rounded-md hover-elevate">
                <Checkbox
                  id="email"
                  checked={channels.email}
                  onCheckedChange={() => handleToggleChannel("email")}
                  data-testid="checkbox-channel-email"
                />
                <div className="flex-1">
                  <Label htmlFor="email" className="flex items-center gap-2 cursor-pointer">
                    <Mail className="w-4 h-4" />
                    <span className="font-medium">Email</span>
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Send via email to all participants
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 border rounded-md hover-elevate">
                <Checkbox
                  id="whatsapp"
                  checked={channels.whatsapp}
                  onCheckedChange={() => handleToggleChannel("whatsapp")}
                  data-testid="checkbox-channel-whatsapp"
                />
                <div className="flex-1">
                  <Label htmlFor="whatsapp" className="flex items-center gap-2 cursor-pointer">
                    <MessageSquare className="w-4 h-4" />
                    <span className="font-medium">WhatsApp</span>
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Send via WhatsApp (requires phone numbers)
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/50 p-3 rounded-md">
              <Clock className="w-4 h-4" />
              <span>Estimated time: ~{Math.ceil(participantCount / 100)} minutes</span>
            </div>
          </div>
        )}

        {step === "sending" && (
          <div className="py-8 space-y-4">
            <Progress value={progress} />
            <p className="text-center text-sm text-muted-foreground">
              Sending {Math.floor((progress / 100) * participantCount)} of {participantCount} certificates...
            </p>
          </div>
        )}

        {step === "complete" && (
          <div className="py-8 flex flex-col items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-chart-2/10 flex items-center justify-center">
              <CheckCircle className="w-10 h-10 text-chart-2" />
            </div>
            <p className="text-center text-muted-foreground">
              {participantCount} certificates sent successfully
            </p>
          </div>
        )}

        {step === "select" && (
          <DialogFooter>
            <Button variant="outline" onClick={onClose} data-testid="button-cancel">
              Cancel
            </Button>
            <Button
              onClick={handleConfirm}
              disabled={!channels.email && !channels.whatsapp}
              data-testid="button-confirm-send"
            >
              Send Now
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}
