import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle, Info } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface NameSuggestion {
  original: string;
  suggested: string;
  confidence: number;
  issue: string;
}

interface AIVerificationPanelProps {
  suggestions: NameSuggestion[];
  onApproveAll?: () => void;
  onReview?: () => void;
}

export function AIVerificationPanel({ suggestions, onApproveAll, onReview }: AIVerificationPanelProps) {
  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 90) return "text-chart-2";
    if (confidence >= 70) return "text-chart-5";
    return "text-destructive";
  };

  const getConfidenceBg = (confidence: number) => {
    if (confidence >= 90) return "bg-chart-2/10";
    if (confidence >= 70) return "bg-chart-5/10";
    return "bg-destructive/10";
  };

  return (
    <Card className="p-6" data-testid="card-ai-verification">
      <div className="flex items-start justify-between mb-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <h3 className="text-lg font-semibold">AI Name Verification</h3>
            <Tooltip>
              <TooltipTrigger>
                <Info className="w-4 h-4 text-muted-foreground" />
              </TooltipTrigger>
              <TooltipContent>
                <p className="max-w-xs text-sm">
                  Our AI analyzes participant names for spelling errors, formatting issues, 
                  and potential mistakes to ensure certificate accuracy.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <p className="text-sm text-muted-foreground">
            {suggestions.length} names flagged for review
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={onReview} data-testid="button-review-individually">
            Review Individually
          </Button>
          <Button size="sm" onClick={onApproveAll} data-testid="button-approve-all">
            Approve All
          </Button>
        </div>
      </div>

      <div className="space-y-3">
        {suggestions.map((suggestion, index) => (
          <div
            key={index}
            className="flex items-center justify-between p-4 border rounded-md hover-elevate"
            data-testid={`item-suggestion-${index}`}
          >
            <div className="flex-1 space-y-2">
              <div className="flex items-center gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm text-muted-foreground line-through">
                      {suggestion.original}
                    </span>
                    <span className="text-muted-foreground">→</span>
                    <span className="font-medium">{suggestion.suggested}</span>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {suggestion.issue}
                  </Badge>
                </div>
                <div className={`px-3 py-1 rounded-md ${getConfidenceBg(suggestion.confidence)}`}>
                  <span className={`text-sm font-mono font-semibold ${getConfidenceColor(suggestion.confidence)}`}>
                    {suggestion.confidence}%
                  </span>
                </div>
              </div>
            </div>
            <div className="flex gap-1 ml-4">
              <Button
                size="icon"
                variant="ghost"
                className="text-chart-2"
                data-testid={`button-accept-${index}`}
              >
                <CheckCircle className="w-4 h-4" />
              </Button>
              <Button
                size="icon"
                variant="ghost"
                className="text-destructive"
                data-testid={`button-reject-${index}`}
              >
                <AlertCircle className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
