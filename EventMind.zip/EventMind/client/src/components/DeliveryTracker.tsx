import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, RefreshCw } from "lucide-react";
import { StatusBadge, DeliveryStatus } from "./StatusBadge";

interface DeliveryRecord {
  id: string;
  participantName: string;
  email: string;
  status: DeliveryStatus;
  sentDate: string;
  channel: string;
  openedAt?: string;
}

interface DeliveryTrackerProps {
  records: DeliveryRecord[];
  stats: {
    delivered: number;
    bounced: number;
    pending: number;
    openRate: number;
  };
  onRefresh?: () => void;
  onExport?: () => void;
}

export function DeliveryTracker({ records, stats, onRefresh, onExport }: DeliveryTrackerProps) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4">
          <p className="text-sm text-muted-foreground mb-1">Delivered</p>
          <p className="text-2xl font-bold text-chart-2">{stats.delivered}</p>
          <p className="text-xs text-muted-foreground mt-1">
            {((stats.delivered / (stats.delivered + stats.bounced + stats.pending)) * 100).toFixed(1)}%
          </p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-muted-foreground mb-1">Bounced</p>
          <p className="text-2xl font-bold text-destructive">{stats.bounced}</p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-muted-foreground mb-1">Pending</p>
          <p className="text-2xl font-bold text-chart-5">{stats.pending}</p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-muted-foreground mb-1">Open Rate</p>
          <p className="text-2xl font-bold">{stats.openRate}%</p>
        </Card>
      </div>

      <Card className="p-6" data-testid="card-delivery-tracker">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold">Delivery History</h3>
            <p className="text-sm text-muted-foreground">
              {records.length} total deliveries
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onRefresh}
              data-testid="button-refresh"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={onExport}
              data-testid="button-export"
            >
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>

        <div className="space-y-3">
          {records.map((record) => (
            <div
              key={record.id}
              className="flex items-center justify-between p-4 border rounded-md hover-elevate"
              data-testid={`item-delivery-${record.id}`}
            >
              <div className="flex-1">
                <p className="font-medium text-sm">{record.participantName}</p>
                <p className="text-xs text-muted-foreground">{record.email}</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">
                    {record.channel} • {record.sentDate}
                  </p>
                  {record.openedAt && (
                    <p className="text-xs text-chart-2">Opened {record.openedAt}</p>
                  )}
                </div>
                <StatusBadge status={record.status} />
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
