import { Badge } from "@/components/ui/badge";

export type DeliveryStatus = "delivered" | "bounced" | "pending" | "not_sent";

interface StatusBadgeProps {
  status: DeliveryStatus;
}

const statusConfig = {
  delivered: {
    label: "Delivered",
    className: "bg-chart-2/10 text-chart-2 border-chart-2/20",
  },
  bounced: {
    label: "Bounced",
    className: "bg-destructive/10 text-destructive border-destructive/20",
  },
  pending: {
    label: "Pending",
    className: "bg-chart-5/10 text-chart-5 border-chart-5/20",
  },
  not_sent: {
    label: "Not Sent",
    className: "bg-muted text-muted-foreground border-muted-foreground/20",
  },
};

export function StatusBadge({ status }: StatusBadgeProps) {
  const config = statusConfig[status];
  
  return (
    <Badge
      variant="outline"
      className={config.className}
      data-testid={`badge-status-${status}`}
    >
      {config.label}
    </Badge>
  );
}
