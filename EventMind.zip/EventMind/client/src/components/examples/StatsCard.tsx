import { StatsCard } from "../StatsCard";
import { Award, CheckCircle, Clock, QrCode } from "lucide-react";

export default function StatsCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-6 bg-background">
      <StatsCard
        title="Total Certificates"
        value="12,847"
        icon={Award}
        color="primary"
        trend={{ value: "+12% from last month", isPositive: true }}
      />
      <StatsCard
        title="Delivery Rate"
        value="98.5%"
        icon={CheckCircle}
        color="success"
        trend={{ value: "+2.1% improvement", isPositive: true }}
      />
      <StatsCard
        title="Pending"
        value="324"
        icon={Clock}
        color="warning"
      />
      <StatsCard
        title="Total Scans"
        value="8,451"
        icon={QrCode}
        color="primary"
        trend={{ value: "+847 today", isPositive: true }}
      />
    </div>
  );
}
