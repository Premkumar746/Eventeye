import { CertificatePreview } from "../CertificatePreview";

export default function CertificatePreviewExample() {
  return (
    <div className="p-6 bg-background max-w-3xl">
      <CertificatePreview
        participantName="Sarah Johnson"
        eventName="Web Development Summit 2025"
        eventDate="January 15, 2025"
        organizerName="EventEye Conferences"
        includeQR={true}
      />
    </div>
  );
}
