import { StatusBadge } from "../StatusBadge";

export default function StatusBadgeExample() {
  return (
    <div className="flex flex-wrap gap-3 p-6 bg-background">
      <StatusBadge status="delivered" />
      <StatusBadge status="pending" />
      <StatusBadge status="bounced" />
      <StatusBadge status="not_sent" />
    </div>
  );
}
