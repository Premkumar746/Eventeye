import { DeliveryTracker } from "../DeliveryTracker";

const mockRecords = [
  {
    id: "1",
    participantName: "Sarah Johnson",
    email: "sarah.johnson@email.com",
    status: "delivered" as const,
    sentDate: "Jan 15, 2025",
    channel: "Email",
    openedAt: "2h ago",
  },
  {
    id: "2",
    participantName: "Michael Chen",
    email: "m.chen@company.io",
    status: "delivered" as const,
    sentDate: "Jan 15, 2025",
    channel: "Email",
    openedAt: "5h ago",
  },
  {
    id: "3",
    participantName: "Emily Rodriguez",
    email: "emily.r@invalid",
    status: "bounced" as const,
    sentDate: "Jan 14, 2025",
    channel: "Email",
  },
  {
    id: "4",
    participantName: "James O'Brien",
    email: "james.obrien@email.com",
    status: "pending" as const,
    sentDate: "Jan 15, 2025",
    channel: "WhatsApp",
  },
];

export default function DeliveryTrackerExample() {
  return (
    <div className="p-6 bg-background">
      <DeliveryTracker
        records={mockRecords}
        stats={{
          delivered: 2847,
          bounced: 143,
          pending: 324,
          openRate: 68.5,
        }}
        onRefresh={() => console.log("Refresh")}
        onExport={() => console.log("Export")}
      />
    </div>
  );
}
