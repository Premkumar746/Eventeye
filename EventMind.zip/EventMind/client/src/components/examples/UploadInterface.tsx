import { UploadInterface } from "../UploadInterface";

export default function UploadInterfaceExample() {
  return (
    <div className="p-6 bg-background max-w-2xl">
      <UploadInterface
        onFileSelect={(file) => console.log("File selected:", file.name)}
        onUploadComplete={() => console.log("Upload complete")}
      />
    </div>
  );
}
