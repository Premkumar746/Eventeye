import { AIVerificationPanel } from "../AIVerificationPanel";

const mockSuggestions = [
  {
    original: "Jhon Doe",
    suggested: "John Doe",
    confidence: 95,
    issue: "Common misspelling",
  },
  {
    original: "SARAH JOHNSON",
    suggested: "Sarah Johnson",
    confidence: 98,
    issue: "Capitalization",
  },
  {
    original: "M1chael Chen",
    suggested: "Michael Chen",
    confidence: 92,
    issue: "Number in name",
  },
  {
    original: "emily  rodriguez",
    suggested: "Emily Rodriguez",
    confidence: 89,
    issue: "Spacing & capitalization",
  },
];

export default function AIVerificationPanelExample() {
  return (
    <div className="p-6 bg-background max-w-4xl">
      <AIVerificationPanel
        suggestions={mockSuggestions}
        onApproveAll={() => console.log("Approve all")}
        onReview={() => console.log("Review individually")}
      />
    </div>
  );
}
