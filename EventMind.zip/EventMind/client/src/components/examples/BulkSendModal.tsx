import { useState } from "react";
import { BulkSendModal } from "../BulkSendModal";
import { Button } from "@/components/ui/button";

export default function BulkSendModalExample() {
  const [open, setOpen] = useState(false);

  return (
    <div className="p-6 bg-background">
      <Button onClick={() => setOpen(true)} data-testid="button-open-modal">
        Open Bulk Send Modal
      </Button>
      <BulkSendModal
        open={open}
        onOpenChange={setOpen}
        participantCount={324}
        onConfirm={(channels) => console.log("Sending via:", channels)}
      />
    </div>
  );
}
