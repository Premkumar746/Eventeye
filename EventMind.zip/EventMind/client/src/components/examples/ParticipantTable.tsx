import { ParticipantTable, Participant } from "../ParticipantTable";

const mockParticipants: Participant[] = [
  {
    id: "1",
    name: "Sarah Johnson",
    email: "sarah.johnson@email.com",
    phone: "+1 234-567-8900",
    status: "delivered",
    sentDate: "2025-01-15",
    aiConfidence: 98,
  },
  {
    id: "2",
    name: "Michael Chen",
    email: "m.chen@company.io",
    phone: "+1 234-567-8901",
    status: "delivered",
    sentDate: "2025-01-15",
    aiConfidence: 95,
  },
  {
    id: "3",
    name: "Emily Rodriguez",
    email: "emily.r@invalid",
    status: "bounced",
    aiConfidence: 72,
  },
  {
    id: "4",
    name: "James O'Brien",
    email: "james.obrien@email.com",
    phone: "+1 234-567-8903",
    status: "pending",
    aiConfidence: 89,
  },
  {
    id: "5",
    name: "Priya Patel",
    email: "priya.patel@company.com",
    status: "not_sent",
    aiConfidence: 100,
  },
];

export default function ParticipantTableExample() {
  return (
    <div className="p-6 bg-background">
      <ParticipantTable
        participants={mockParticipants}
        onSendBulk={(ids) => console.log("Send bulk to:", ids)}
        onResend={(id) => console.log("Resend to:", id)}
        onDelete={(ids) => console.log("Delete:", ids)}
      />
    </div>
  );
}
