import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { StatsCard } from "@/components/StatsCard";
import { DeliveryTracker } from "@/components/DeliveryTracker";
import { AIVerificationPanel } from "@/components/AIVerificationPanel";
import { BulkSendModal } from "@/components/BulkSendModal";
import { Button } from "@/components/ui/button";
import { Award, CheckCircle, Clock, QrCode, Plus, Upload, Send } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import type { Event } from "@shared/schema";

export default function Dashboard() {
  const [showBulkSend, setShowBulkSend] = useState(false);

  const { data: events, isLoading: eventsLoading } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });

  const eventId = events?.[0]?.id;

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/events", eventId, "stats"],
    enabled: !!eventId,
  });

  const { data: deliveryRecords, isLoading: recordsLoading } = useQuery({
    queryKey: ["/api/events", eventId, "delivery-records"],
    enabled: !!eventId,
  });

  const { data: participants } = useQuery({
    queryKey: ["/api/events", eventId, "participants"],
    enabled: !!eventId,
  });

  const lowConfidenceParticipants = participants?.filter((p: any) => p.aiConfidence < 90) || [];
  
  const mockSuggestions = lowConfidenceParticipants.map((p: any) => ({
    original: p.originalName || p.name,
    suggested: p.name,
    confidence: p.aiConfidence,
    issue: p.originalName ? "AI corrected" : "Low confidence",
  }));

  const isLoading = eventsLoading || statsLoading || recordsLoading;

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
          <p className="text-muted-foreground">
            Manage and track your certificate automation
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      </div>
    );
  }

  const formattedRecords = deliveryRecords?.map((record: any) => ({
    id: record.id,
    participantName: record.participantName,
    email: record.email,
    status: record.status,
    sentDate: record.sentDate,
    channel: record.channel === "email" ? "Email" : "WhatsApp",
    openedAt: record.openedAt,
  })) || [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">
          Manage and track your certificate automation
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Total Certificates"
          value={stats?.totalCertificates?.toString() || "0"}
          icon={Award}
          color="primary"
        />
        <StatsCard
          title="Delivered"
          value={stats?.delivered?.toString() || "0"}
          icon={CheckCircle}
          color="success"
        />
        <StatsCard
          title="Pending"
          value={stats?.pending?.toString() || "0"}
          icon={Clock}
          color="warning"
        />
        <StatsCard
          title="Total Scans"
          value={stats?.totalScans?.toString() || "0"}
          icon={QrCode}
          color="primary"
        />
      </div>

      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
        <div className="flex flex-wrap gap-3">
          <Button data-testid="button-new-certificate">
            <Plus className="w-4 h-4 mr-2" />
            New Certificate
          </Button>
          <Button variant="outline" data-testid="button-upload-participants">
            <Upload className="w-4 h-4 mr-2" />
            Upload Participants
          </Button>
          <Button
            variant="outline"
            onClick={() => setShowBulkSend(true)}
            data-testid="button-send-batch"
          >
            <Send className="w-4 h-4 mr-2" />
            Send Batch
          </Button>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <DeliveryTracker
            records={formattedRecords}
            stats={{
              delivered: stats?.delivered || 0,
              bounced: stats?.bounced || 0,
              pending: stats?.pending || 0,
              openRate: stats?.openRate || "0.0",
            }}
          />
        </div>
        <div>
          <AIVerificationPanel
            suggestions={mockSuggestions}
            onAcceptAll={() => console.log("Accept all suggestions")}
            onReject={(index) => console.log("Reject suggestion", index)}
          />
        </div>
      </div>

      {showBulkSend && eventId && (
        <BulkSendModal
          eventId={eventId}
          onClose={() => setShowBulkSend(false)}
        />
      )}
    </div>
  );
}
