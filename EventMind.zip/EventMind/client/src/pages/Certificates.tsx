import { useState } from "react";
import { CertificatePreview } from "@/components/CertificatePreview";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Download, Save } from "lucide-react";

export default function Certificates() {
  const [formData, setFormData] = useState({
    participantName: "Sarah Johnson",
    eventName: "Web Development Summit 2025",
    eventDate: "January 15, 2025",
    organizerName: "EventEye Conferences",
    includeQR: true,
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Certificate Builder</h1>
        <p className="text-muted-foreground">
          Design and customize your certificate templates
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Certificate Details</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="participant-name">Participant Name</Label>
                <Input
                  id="participant-name"
                  value={formData.participantName}
                  onChange={(e) => setFormData({ ...formData, participantName: e.target.value })}
                  data-testid="input-participant-name"
                />
              </div>
              <div>
                <Label htmlFor="event-name">Event Name</Label>
                <Input
                  id="event-name"
                  value={formData.eventName}
                  onChange={(e) => setFormData({ ...formData, eventName: e.target.value })}
                  data-testid="input-event-name"
                />
              </div>
              <div>
                <Label htmlFor="event-date">Event Date</Label>
                <Input
                  id="event-date"
                  value={formData.eventDate}
                  onChange={(e) => setFormData({ ...formData, eventDate: e.target.value })}
                  data-testid="input-event-date"
                />
              </div>
              <div>
                <Label htmlFor="organizer-name">Organizer Name</Label>
                <Input
                  id="organizer-name"
                  value={formData.organizerName}
                  onChange={(e) => setFormData({ ...formData, organizerName: e.target.value })}
                  data-testid="input-organizer-name"
                />
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="include-qr"
                  checked={formData.includeQR}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, includeQR: checked as boolean })
                  }
                  data-testid="checkbox-include-qr"
                />
                <Label htmlFor="include-qr" className="cursor-pointer">
                  Include QR Code
                </Label>
              </div>
            </div>
          </Card>

          <div className="flex gap-2">
            <Button className="flex-1" data-testid="button-save-template">
              <Save className="w-4 h-4 mr-2" />
              Save Template
            </Button>
            <Button variant="outline" className="flex-1" data-testid="button-download">
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
          </div>
        </div>

        <div className="lg:col-span-3">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Live Preview</h3>
            <CertificatePreview
              participantName={formData.participantName}
              eventName={formData.eventName}
              eventDate={formData.eventDate}
              organizerName={formData.organizerName}
              includeQR={formData.includeQR}
            />
          </Card>
        </div>
      </div>
    </div>
  );
}
