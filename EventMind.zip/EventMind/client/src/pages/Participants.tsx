import { useQuery } from "@tanstack/react-query";
import { ParticipantTable, Participant } from "@/components/ParticipantTable";
import { UploadInterface } from "@/components/UploadInterface";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useState } from "react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Event } from "@shared/schema";

export default function Participants() {
  const [showUpload, setShowUpload] = useState(false);
  const { toast } = useToast();

  const { data: events } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });

  const eventId = events?.[0]?.id;

  const { data: participants, isLoading } = useQuery<Participant[]>({
    queryKey: ["/api/events", eventId, "participants"],
    enabled: !!eventId,
  });

  const handleFileSelect = async (file: File) => {
    if (!eventId) return;

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch(`/api/events/${eventId}/participants/upload`, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Upload failed");
      }

      const result = await response.json();
      
      toast({
        title: "Upload successful",
        description: `Imported ${result.count} participants${result.skipped ? `, skipped ${result.skipped} invalid rows` : ""}`,
      });

      queryClient.invalidateQueries({ queryKey: ["/api/events", eventId, "participants"] });
      setShowUpload(false);
    } catch (error) {
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload file",
        variant: "destructive",
      });
    }
  };

  const handleSendBulk = async (ids: string[]) => {
    try {
      await apiRequest("/api/participants/bulk-send", {
        method: "POST",
        body: JSON.stringify({
          participantIds: ids,
          channels: ["email"],
        }),
        headers: { "Content-Type": "application/json" },
      });

      toast({
        title: "Certificates sent",
        description: `Sent certificates to ${ids.length} participants`,
      });

      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
    } catch (error) {
      toast({
        title: "Send failed",
        description: "Failed to send certificates",
        variant: "destructive",
      });
    }
  };

  const handleResend = async (id: string) => {
    await handleSendBulk([id]);
  };

  const handleDelete = async (ids: string[]) => {
    try {
      await apiRequest("/api/participants/bulk-delete", {
        method: "POST",
        body: JSON.stringify({ ids }),
        headers: { "Content-Type": "application/json" },
      });

      toast({
        title: "Deleted successfully",
        description: `Deleted ${ids.length} participant(s)`,
      });

      queryClient.invalidateQueries({ queryKey: ["/api/events", eventId, "participants"] });
    } catch (error) {
      toast({
        title: "Delete failed",
        description: "Failed to delete participants",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Participants</h1>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Participants</h1>
          <p className="text-muted-foreground">
            Manage participant data and delivery status
          </p>
        </div>
        <Button
          onClick={() => setShowUpload(!showUpload)}
          data-testid="button-add-participant"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Participant
        </Button>
      </div>

      {showUpload && (
        <UploadInterface
          onFileSelect={handleFileSelect}
          onUploadComplete={() => setShowUpload(false)}
        />
      )}

      <ParticipantTable
        participants={participants || []}
        onSendBulk={handleSendBulk}
        onResend={handleResend}
        onDelete={handleDelete}
      />
    </div>
  );
}
