import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import Dashboard from "@/pages/Dashboard";
import Certificates from "@/pages/Certificates";
import Participants from "@/pages/Participants";
import NotFound from "@/pages/not-found";
import { Bell, User } from "lucide-react";
import { Button } from "@/components/ui/button";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/certificates" component={Certificates} />
      <Route path="/participants" component={Participants} />
      <Route path="/templates" component={() => <div className="p-6">Templates page - Coming soon</div>} />
      <Route path="/analytics" component={() => <div className="p-6">Analytics page - Coming soon</div>} />
      <Route path="/settings" component={() => <div className="p-6">Settings page - Coming soon</div>} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <SidebarProvider style={style as React.CSSProperties}>
            <div className="flex h-screen w-full">
              <AppSidebar />
              <div className="flex flex-col flex-1 overflow-hidden">
                <header className="flex items-center justify-between px-6 py-3 border-b bg-background">
                  <SidebarTrigger data-testid="button-sidebar-toggle" />
                  <div className="flex items-center gap-2">
                    <Button size="icon" variant="ghost" data-testid="button-notifications">
                      <Bell className="w-5 h-5" />
                    </Button>
                    <Button size="icon" variant="ghost" data-testid="button-profile">
                      <User className="w-5 h-5" />
                    </Button>
                  </div>
                </header>
                <main className="flex-1 overflow-y-auto p-6">
                  <Router />
                </main>
              </div>
            </div>
          </SidebarProvider>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}
