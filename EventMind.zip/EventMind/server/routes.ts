import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import { parse } from "csv-parse/sync";
import {
  insertParticipantSchema,
  insertEventSchema,
  insertDeliveryRecordSchema,
  insertCertificateTemplateSchema,
} from "@shared/schema";
import { z } from "zod";
import { generateCertificatePDF, verifyQRData } from "./certificate-generator";

const upload = multer({ storage: multer.memoryStorage() });

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/events", async (req: Request, res: Response) => {
    try {
      const events = await storage.getAllEvents();
      res.json(events);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch events" });
    }
  });

  app.get("/api/events/:id", async (req: Request, res: Response) => {
    try {
      const event = await storage.getEvent(req.params.id);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.json(event);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch event" });
    }
  });

  app.post("/api/events", async (req: Request, res: Response) => {
    try {
      const validated = insertEventSchema.parse(req.body);
      const event = await storage.createEvent(validated);
      res.status(201).json(event);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create event" });
    }
  });

  app.put("/api/events/:id", async (req: Request, res: Response) => {
    try {
      const validated = insertEventSchema.partial().parse(req.body);
      const event = await storage.updateEvent(req.params.id, validated);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.json(event);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update event" });
    }
  });

  app.delete("/api/events/:id", async (req: Request, res: Response) => {
    try {
      const success = await storage.deleteEventCascade(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete event" });
    }
  });

  app.get("/api/events/:eventId/participants", async (req: Request, res: Response) => {
    try {
      const participants = await storage.getParticipantsByEvent(req.params.eventId);
      
      const participantsWithStatus = await Promise.all(
        participants.map(async (p) => {
          const records = await storage.getDeliveryRecordsByParticipant(p.id);
          const latestRecord = records.sort((a, b) => 
            (b.sentDate || "").localeCompare(a.sentDate || "")
          )[0];
          
          return {
            ...p,
            status: latestRecord?.status || "not_sent",
            sentDate: latestRecord?.sentDate || null,
          };
        })
      );
      
      res.json(participantsWithStatus);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch participants" });
    }
  });

  app.get("/api/participants/:id", async (req: Request, res: Response) => {
    try {
      const participant = await storage.getParticipant(req.params.id);
      if (!participant) {
        return res.status(404).json({ error: "Participant not found" });
      }
      res.json(participant);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch participant" });
    }
  });

  app.post("/api/events/:eventId/participants", async (req: Request, res: Response) => {
    try {
      const validated = insertParticipantSchema.parse({
        ...req.body,
        eventId: req.params.eventId,
      });
      const participant = await storage.createParticipant(validated);
      res.status(201).json(participant);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create participant" });
    }
  });

  app.post(
    "/api/events/:eventId/participants/upload",
    upload.single("file"),
    async (req: Request, res: Response) => {
      try {
        if (!req.file) {
          return res.status(400).json({ error: "No file uploaded" });
        }

        const csvData = req.file.buffer.toString("utf-8");
        const records = parse(csvData, {
          columns: true,
          skip_empty_lines: true,
          trim: true,
        });

        const validParticipants = [];
        const errors = [];

        for (let i = 0; i < records.length; i++) {
          const record: any = records[i];
          try {
            const validated = insertParticipantSchema.parse({
              eventId: req.params.eventId,
              name: record.Name || record.name,
              email: record.Email || record.email,
              phone: record.Phone || record.phone || undefined,
              aiConfidence: 85,
            });
            validParticipants.push(validated);
          } catch (validationError) {
            if (validationError instanceof z.ZodError) {
              errors.push({
                row: i + 2,
                errors: validationError.errors,
              });
            }
          }
        }

        if (validParticipants.length === 0) {
          return res.status(400).json({ 
            error: "No valid participants found", 
            details: errors 
          });
        }

        const created = await storage.createParticipants(validParticipants);
        res.status(201).json({ 
          count: created.length, 
          participants: created,
          skipped: errors.length,
          errors: errors.length > 0 ? errors : undefined,
        });
      } catch (error) {
        console.error("CSV upload error:", error);
        res.status(500).json({ error: "Failed to process CSV file" });
      }
    }
  );

  app.put("/api/participants/:id", async (req: Request, res: Response) => {
    try {
      const validated = insertParticipantSchema.partial().parse(req.body);
      const participant = await storage.updateParticipant(req.params.id, validated);
      if (!participant) {
        return res.status(404).json({ error: "Participant not found" });
      }
      res.json(participant);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update participant" });
    }
  });

  app.delete("/api/participants/:id", async (req: Request, res: Response) => {
    try {
      const success = await storage.deleteParticipantCascade(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Participant not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete participant" });
    }
  });

  app.post("/api/participants/bulk-delete", async (req: Request, res: Response) => {
    try {
      const requestSchema = z.object({
        ids: z.array(z.string()).min(1, "At least one participant ID required"),
      });
      
      const { ids } = requestSchema.parse(req.body);
      const count = await storage.deleteParticipants(ids);
      res.json({ deleted: count });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to delete participants" });
    }
  });

  app.post("/api/participants/bulk-send", async (req: Request, res: Response) => {
    try {
      const requestSchema = z.object({
        participantIds: z.array(z.string()).min(1, "At least one participant required"),
        channels: z.array(z.enum(["email", "whatsapp"])).min(1, "At least one channel required"),
      });

      const { participantIds, channels } = requestSchema.parse(req.body);

      const results = [];
      for (const participantId of participantIds) {
        const participant = await storage.getParticipant(participantId);
        if (!participant) continue;

        for (const channel of channels) {
          const isEmailValid = channel === "email" && 
            participant.email && 
            participant.email.includes("@");
          const hasPhone = channel === "whatsapp" && 
            participant.phone && 
            participant.phone.length > 0;
          
          let status: "delivered" | "bounced" | "pending" = "delivered";
          let bounceReason = null;

          if (channel === "email" && !isEmailValid) {
            status = "bounced";
            bounceReason = "Invalid email address";
          } else if (channel === "whatsapp" && !hasPhone) {
            status = "pending";
          } else {
            const randomFail = Math.random() < 0.05;
            if (randomFail) {
              status = "bounced";
              bounceReason = channel === "email" ? "Mailbox full" : "Invalid phone number";
            }
          }

          const validated = insertDeliveryRecordSchema.parse({
            participantId,
            status,
            channel,
            sentDate: new Date().toISOString().split("T")[0],
            openedAt: undefined,
            bounceReason: bounceReason || undefined,
          });

          const record = await storage.createDeliveryRecord(validated);
          results.push(record);
        }
      }

      res.json({ sent: results.length, results });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Bulk send error:", error);
      res.status(500).json({ error: "Failed to send certificates" });
    }
  });

  app.get("/api/events/:eventId/delivery-records", async (req: Request, res: Response) => {
    try {
      const records = await storage.getDeliveryRecordsByEvent(req.params.eventId);
      const participants = await storage.getParticipantsByEvent(req.params.eventId);
      const participantMap = new Map(participants.map((p) => [p.id, p]));
      
      const enrichedRecords = records.map((record) => {
        const participant = participantMap.get(record.participantId);
        return {
          ...record,
          participantName: participant?.name || "Unknown",
          email: participant?.email || "Unknown",
        };
      });
      
      res.json(enrichedRecords);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch delivery records" });
    }
  });

  app.get("/api/events/:eventId/stats", async (req: Request, res: Response) => {
    try {
      const participants = await storage.getParticipantsByEvent(req.params.eventId);
      const records = await storage.getDeliveryRecordsByEvent(req.params.eventId);
      
      const delivered = records.filter((r) => r.status === "delivered").length;
      const bounced = records.filter((r) => r.status === "bounced").length;
      const pending = records.filter((r) => r.status === "pending").length;
      const opened = records.filter((r) => r.openedAt).length;
      
      const stats = {
        totalCertificates: participants.length,
        delivered,
        bounced,
        pending,
        openRate: delivered > 0 ? ((opened / delivered) * 100).toFixed(1) : "0.0",
        totalScans: Math.floor(Math.random() * 10000) + 1000,
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  app.get("/api/events/:eventId/templates", async (req: Request, res: Response) => {
    try {
      const templates = await storage.getTemplatesByEvent(req.params.eventId);
      res.json(templates);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch templates" });
    }
  });

  app.post("/api/events/:eventId/templates", async (req: Request, res: Response) => {
    try {
      const validated = insertCertificateTemplateSchema.parse({
        ...req.body,
        eventId: req.params.eventId,
      });
      const template = await storage.createTemplate(validated);
      res.status(201).json(template);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create template" });
    }
  });

  app.post("/api/participants/:id/verify-name", async (req: Request, res: Response) => {
    try {
      const participant = await storage.getParticipant(req.params.id);
      if (!participant) {
        return res.status(404).json({ error: "Participant not found" });
      }

      const originalName = participant.name;
      const suggestions = analyzeNameForIssues(originalName);
      
      res.json({
        original: originalName,
        suggestions,
        confidence: suggestions.length === 0 ? 100 : Math.max(70, 100 - suggestions.length * 10),
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to verify name" });
    }
  });

  app.get("/api/participants/:participantId/certificate", async (req: Request, res: Response) => {
    try {
      const participant = await storage.getParticipant(req.params.participantId);
      if (!participant) {
        return res.status(404).json({ error: "Participant not found" });
      }

      const event = await storage.getEvent(participant.eventId);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }

      const templates = await storage.getTemplatesByEvent(participant.eventId);
      const template = templates[0];
      if (!template) {
        return res.status(404).json({ error: "No template found for event" });
      }

      const pdfBuffer = await generateCertificatePDF(participant, template, event);
      
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="certificate-${participant.name.replace(/\s+/g, "-")}.pdf"`
      );
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Certificate generation error:", error);
      res.status(500).json({ error: "Failed to generate certificate" });
    }
  });

  app.post("/api/verify-qr", async (req: Request, res: Response) => {
    try {
      const { qrData } = req.body;
      if (!qrData) {
        return res.status(400).json({ error: "QR data is required" });
      }

      const parseResult = verifyQRData(qrData);
      if (!parseResult.valid) {
        return res.json(parseResult);
      }

      const data = parseResult.data!;
      
      const participant = await storage.getParticipant(data.participantId);
      if (!participant) {
        return res.json({ 
          valid: false, 
          error: "Participant not found in system" 
        });
      }

      if (participant.name !== data.participantName) {
        return res.json({ 
          valid: false, 
          error: "Participant name mismatch" 
        });
      }

      const event = await storage.getEvent(participant.eventId);
      if (!event) {
        return res.json({ 
          valid: false, 
          error: "Event not found in system" 
        });
      }

      if (event.name !== data.eventName || event.date !== data.eventDate) {
        return res.json({ 
          valid: false, 
          error: "Event details mismatch" 
        });
      }

      res.json({ 
        valid: true, 
        data: {
          participantId: participant.id,
          participantName: participant.name,
          participantEmail: participant.email,
          eventName: event.name,
          eventDate: event.date,
          issueDate: data.issueDate,
          verified: true,
        }
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to verify QR code" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function analyzeNameForIssues(name: string): Array<{suggested: string, issue: string, confidence: number}> {
  const suggestions = [];
  
  if (name === name.toUpperCase()) {
    suggestions.push({
      suggested: name.split(" ").map(word => 
        word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
      ).join(" "),
      issue: "All caps",
      confidence: 98,
    });
  }
  
  if (name === name.toLowerCase()) {
    suggestions.push({
      suggested: name.split(" ").map(word => 
        word.charAt(0).toUpperCase() + word.slice(1)
      ).join(" "),
      issue: "All lowercase",
      confidence: 96,
    });
  }
  
  if (/\d/.test(name)) {
    suggestions.push({
      suggested: name.replace(/\d/g, ""),
      issue: "Contains numbers",
      confidence: 92,
    });
  }
  
  if (/\s{2,}/.test(name)) {
    suggestions.push({
      suggested: name.replace(/\s+/g, " "),
      issue: "Extra spaces",
      confidence: 95,
    });
  }
  
  const commonTypos: Record<string, string> = {
    "jhon": "john",
    "micheal": "michael",
    "sara": "sarah",
  };
  
  let suggested = name;
  let foundTypo = false;
  for (const [typo, correct] of Object.entries(commonTypos)) {
    if (name.toLowerCase().includes(typo)) {
      suggested = name.toLowerCase().replace(typo, correct);
      suggested = suggested.split(" ").map(word => 
        word.charAt(0).toUpperCase() + word.slice(1)
      ).join(" ");
      foundTypo = true;
      break;
    }
  }
  
  if (foundTypo) {
    suggestions.push({
      suggested,
      issue: "Common misspelling",
      confidence: 95,
    });
  }
  
  return suggestions;
}
