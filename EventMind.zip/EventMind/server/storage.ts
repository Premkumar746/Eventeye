import {
  type User,
  type InsertUser,
  type Event,
  type InsertEvent,
  type CertificateTemplate,
  type InsertCertificateTemplate,
  type Participant,
  type InsertParticipant,
  type DeliveryRecord,
  type InsertDeliveryRecord,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getEvent(id: string): Promise<Event | undefined>;
  getAllEvents(): Promise<Event[]>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: string, event: Partial<InsertEvent>): Promise<Event | undefined>;
  deleteEvent(id: string): Promise<boolean>;
  deleteEventCascade(id: string): Promise<boolean>;

  getTemplate(id: string): Promise<CertificateTemplate | undefined>;
  getTemplatesByEvent(eventId: string): Promise<CertificateTemplate[]>;
  createTemplate(template: InsertCertificateTemplate): Promise<CertificateTemplate>;
  updateTemplate(id: string, template: Partial<InsertCertificateTemplate>): Promise<CertificateTemplate | undefined>;
  deleteTemplate(id: string): Promise<boolean>;

  getParticipant(id: string): Promise<Participant | undefined>;
  getParticipantsByEvent(eventId: string): Promise<Participant[]>;
  createParticipant(participant: InsertParticipant): Promise<Participant>;
  createParticipants(participants: InsertParticipant[]): Promise<Participant[]>;
  updateParticipant(id: string, participant: Partial<InsertParticipant>): Promise<Participant | undefined>;
  deleteParticipant(id: string): Promise<boolean>;
  deleteParticipants(ids: string[]): Promise<number>;
  deleteParticipantCascade(id: string): Promise<boolean>;

  getDeliveryRecord(id: string): Promise<DeliveryRecord | undefined>;
  getDeliveryRecordsByParticipant(participantId: string): Promise<DeliveryRecord[]>;
  getDeliveryRecordsByEvent(eventId: string): Promise<DeliveryRecord[]>;
  createDeliveryRecord(record: InsertDeliveryRecord): Promise<DeliveryRecord>;
  updateDeliveryRecord(id: string, record: Partial<InsertDeliveryRecord>): Promise<DeliveryRecord | undefined>;
  deleteDeliveryRecord(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private events: Map<string, Event>;
  private templates: Map<string, CertificateTemplate>;
  private participants: Map<string, Participant>;
  private deliveryRecords: Map<string, DeliveryRecord>;

  constructor() {
    this.users = new Map();
    this.events = new Map();
    this.templates = new Map();
    this.participants = new Map();
    this.deliveryRecords = new Map();
    this.seedData();
  }

  private seedData() {
    const eventId = randomUUID();
    const event: Event = {
      id: eventId,
      name: "Web Development Summit 2025",
      date: "January 15, 2025",
      organizerName: "EventEye Conferences",
    };
    this.events.set(eventId, event);

    const templateId = randomUUID();
    const template: CertificateTemplate = {
      id: templateId,
      eventId: eventId,
      name: "Default Template",
      title: "Certificate of Participation",
      headerText: "EventEye Conferences Presents",
      footerText: "Thank you for your participation and dedication",
      includeQR: true,
    };
    this.templates.set(templateId, template);

    const participantData = [
      { name: "Sarah Johnson", email: "sarah.johnson@email.com", phone: "+1 234-567-8900", aiConfidence: 98 },
      { name: "Michael Chen", email: "m.chen@company.io", phone: "+1 234-567-8901", aiConfidence: 95 },
      { name: "Emily Rodriguez", email: "emily.r@invalid", aiConfidence: 72, originalName: "EMILY RODRIGUEZ" },
      { name: "James O'Brien", email: "james.obrien@email.com", phone: "+1 234-567-8903", aiConfidence: 89 },
      { name: "Priya Patel", email: "priya.patel@company.com", aiConfidence: 100 },
      { name: "Alex Thompson", email: "alex.t@email.com", phone: "+1 234-567-8904", aiConfidence: 96 },
    ];

    participantData.forEach((p, index) => {
      const participantId = randomUUID();
      const participant: Participant = {
        id: participantId,
        eventId: eventId,
        name: p.name,
        email: p.email,
        phone: p.phone || null,
        aiConfidence: p.aiConfidence,
        originalName: p.originalName || null,
      };
      this.participants.set(participantId, participant);

      if (index < 2) {
        const recordId = randomUUID();
        const record: DeliveryRecord = {
          id: recordId,
          participantId: participantId,
          status: "delivered",
          channel: "email",
          sentDate: "2025-01-15",
          openedAt: index === 0 ? "2h ago" : "5h ago",
          bounceReason: null,
        };
        this.deliveryRecords.set(recordId, record);
      } else if (index === 2) {
        const recordId = randomUUID();
        const record: DeliveryRecord = {
          id: recordId,
          participantId: participantId,
          status: "bounced",
          channel: "email",
          sentDate: "2025-01-14",
          openedAt: null,
          bounceReason: "Invalid email address",
        };
        this.deliveryRecords.set(recordId, record);
      } else if (index === 3) {
        const recordId = randomUUID();
        const record: DeliveryRecord = {
          id: recordId,
          participantId: participantId,
          status: "pending",
          channel: "whatsapp",
          sentDate: "2025-01-15",
          openedAt: null,
          bounceReason: null,
        };
        this.deliveryRecords.set(recordId, record);
      }
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getEvent(id: string): Promise<Event | undefined> {
    return this.events.get(id);
  }

  async getAllEvents(): Promise<Event[]> {
    return Array.from(this.events.values());
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const id = randomUUID();
    const event: Event = { ...insertEvent, id };
    this.events.set(id, event);
    return event;
  }

  async updateEvent(id: string, updateData: Partial<InsertEvent>): Promise<Event | undefined> {
    const event = this.events.get(id);
    if (!event) return undefined;
    const updated = { ...event, ...updateData };
    this.events.set(id, updated);
    return updated;
  }

  async deleteEvent(id: string): Promise<boolean> {
    return this.events.delete(id);
  }

  async deleteEventCascade(id: string): Promise<boolean> {
    const templates = await this.getTemplatesByEvent(id);
    templates.forEach((t) => this.templates.delete(t.id));
    
    const participants = await this.getParticipantsByEvent(id);
    for (const participant of participants) {
      await this.deleteParticipantCascade(participant.id);
    }
    
    return this.events.delete(id);
  }

  async getTemplate(id: string): Promise<CertificateTemplate | undefined> {
    return this.templates.get(id);
  }

  async getTemplatesByEvent(eventId: string): Promise<CertificateTemplate[]> {
    return Array.from(this.templates.values()).filter((t) => t.eventId === eventId);
  }

  async createTemplate(insertTemplate: InsertCertificateTemplate): Promise<CertificateTemplate> {
    const id = randomUUID();
    const template: CertificateTemplate = { 
      ...insertTemplate, 
      id,
      includeQR: insertTemplate.includeQR ?? true,
    };
    this.templates.set(id, template);
    return template;
  }

  async updateTemplate(id: string, updateData: Partial<InsertCertificateTemplate>): Promise<CertificateTemplate | undefined> {
    const template = this.templates.get(id);
    if (!template) return undefined;
    const updated: CertificateTemplate = { 
      ...template, 
      ...updateData,
      includeQR: updateData.includeQR !== undefined ? (updateData.includeQR ?? null) : template.includeQR,
    };
    this.templates.set(id, updated);
    return updated;
  }

  async deleteTemplate(id: string): Promise<boolean> {
    return this.templates.delete(id);
  }

  async getParticipant(id: string): Promise<Participant | undefined> {
    return this.participants.get(id);
  }

  async getParticipantsByEvent(eventId: string): Promise<Participant[]> {
    return Array.from(this.participants.values()).filter((p) => p.eventId === eventId);
  }

  async createParticipant(insertParticipant: InsertParticipant): Promise<Participant> {
    const id = randomUUID();
    const participant: Participant = { 
      ...insertParticipant, 
      id,
      phone: insertParticipant.phone ?? null,
      aiConfidence: insertParticipant.aiConfidence ?? null,
      originalName: insertParticipant.originalName ?? null,
    };
    this.participants.set(id, participant);
    return participant;
  }

  async createParticipants(insertParticipants: InsertParticipant[]): Promise<Participant[]> {
    return Promise.all(insertParticipants.map((p) => this.createParticipant(p)));
  }

  async updateParticipant(id: string, updateData: Partial<InsertParticipant>): Promise<Participant | undefined> {
    const participant = this.participants.get(id);
    if (!participant) return undefined;
    const updated: Participant = { 
      ...participant, 
      ...updateData,
      phone: updateData.phone !== undefined ? (updateData.phone ?? null) : participant.phone,
      aiConfidence: updateData.aiConfidence !== undefined ? (updateData.aiConfidence ?? null) : participant.aiConfidence,
      originalName: updateData.originalName !== undefined ? (updateData.originalName ?? null) : participant.originalName,
    };
    this.participants.set(id, updated);
    return updated;
  }

  async deleteParticipant(id: string): Promise<boolean> {
    return this.participants.delete(id);
  }

  async deleteParticipants(ids: string[]): Promise<number> {
    let deleted = 0;
    for (const id of ids) {
      const success = await this.deleteParticipantCascade(id);
      if (success) deleted++;
    }
    return deleted;
  }

  async deleteParticipantCascade(id: string): Promise<boolean> {
    const records = await this.getDeliveryRecordsByParticipant(id);
    records.forEach((r) => this.deliveryRecords.delete(r.id));
    return this.participants.delete(id);
  }

  async getDeliveryRecord(id: string): Promise<DeliveryRecord | undefined> {
    return this.deliveryRecords.get(id);
  }

  async getDeliveryRecordsByParticipant(participantId: string): Promise<DeliveryRecord[]> {
    return Array.from(this.deliveryRecords.values()).filter(
      (r) => r.participantId === participantId
    );
  }

  async getDeliveryRecordsByEvent(eventId: string): Promise<DeliveryRecord[]> {
    const participants = await this.getParticipantsByEvent(eventId);
    const participantIds = new Set(participants.map((p) => p.id));
    return Array.from(this.deliveryRecords.values()).filter(
      (r) => participantIds.has(r.participantId)
    );
  }

  async createDeliveryRecord(insertRecord: InsertDeliveryRecord): Promise<DeliveryRecord> {
    const id = randomUUID();
    const record: DeliveryRecord = { 
      ...insertRecord, 
      id,
      sentDate: insertRecord.sentDate ?? null,
      openedAt: insertRecord.openedAt ?? null,
      bounceReason: insertRecord.bounceReason ?? null,
    };
    this.deliveryRecords.set(id, record);
    return record;
  }

  async updateDeliveryRecord(id: string, updateData: Partial<InsertDeliveryRecord>): Promise<DeliveryRecord | undefined> {
    const record = this.deliveryRecords.get(id);
    if (!record) return undefined;
    const updated: DeliveryRecord = { 
      ...record, 
      ...updateData,
      sentDate: updateData.sentDate !== undefined ? (updateData.sentDate ?? null) : record.sentDate,
      openedAt: updateData.openedAt !== undefined ? (updateData.openedAt ?? null) : record.openedAt,
      bounceReason: updateData.bounceReason !== undefined ? (updateData.bounceReason ?? null) : record.bounceReason,
    };
    this.deliveryRecords.set(id, updated);
    return updated;
  }

  async deleteDeliveryRecord(id: string): Promise<boolean> {
    return this.deliveryRecords.delete(id);
  }
}

export const storage = new MemStorage();
