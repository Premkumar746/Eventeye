import QRCode from "qrcode";
import PDFDocument from "pdfkit";
import type { Participant, CertificateTemplate } from "@shared/schema";

export async function generateQRCode(data: string): Promise<string> {
  try {
    return await QRCode.toDataURL(data, {
      errorCorrectionLevel: "H",
      margin: 1,
      width: 200,
    });
  } catch (error) {
    console.error("QR code generation error:", error);
    throw new Error("Failed to generate QR code");
  }
}

export async function generateCertificatePDF(
  participant: Participant,
  template: CertificateTemplate,
  event: { name: string; date: string }
): Promise<Buffer> {
  return new Promise(async (resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: "A4",
        layout: "landscape",
        margins: { top: 50, bottom: 50, left: 50, right: 50 },
      });

      const chunks: Buffer[] = [];
      doc.on("data", (chunk) => chunks.push(chunk));
      doc.on("end", () => resolve(Buffer.concat(chunks)));
      doc.on("error", reject);

      const pageWidth = doc.page.width;
      const pageHeight = doc.page.height;
      const centerX = pageWidth / 2;

      if (template.headerText) {
        doc
          .fontSize(16)
          .fillColor("#6B7280")
          .text(template.headerText, 0, 60, {
            align: "center",
            width: pageWidth,
          });
      }

      doc
        .fontSize(36)
        .fillColor("#7C3AED")
        .text(template.title, 0, 120, {
          align: "center",
          width: pageWidth,
        });

      doc
        .fontSize(14)
        .fillColor("#374151")
        .text("This certificate is awarded to", 0, 190, {
          align: "center",
          width: pageWidth,
        });

      doc
        .fontSize(32)
        .fillColor("#111827")
        .font("Helvetica-Bold")
        .text(participant.name, 0, 230, {
          align: "center",
          width: pageWidth,
        });

      doc
        .fontSize(14)
        .fillColor("#374151")
        .font("Helvetica")
        .text("for successfully participating in", 0, 290, {
          align: "center",
          width: pageWidth,
        });

      doc
        .fontSize(24)
        .fillColor("#7C3AED")
        .text(event.name, 0, 320, {
          align: "center",
          width: pageWidth,
        });

      if (template.footerText) {
        doc
          .fontSize(12)
          .fillColor("#6B7280")
          .text(template.footerText, 0, 380, {
            align: "center",
            width: pageWidth,
          });
      }

      doc
        .fontSize(11)
        .fillColor("#9CA3AF")
        .text(`Date: ${event.date}`, 0, 430, {
          align: "center",
          width: pageWidth,
        });

      if (template.includeQR) {
        const verificationData = JSON.stringify({
          participantId: participant.id,
          participantName: participant.name,
          eventName: event.name,
          eventDate: event.date,
          issueDate: new Date().toISOString().split("T")[0],
        });

        const qrCodeDataUrl = await generateQRCode(verificationData);
        const qrImageBuffer = Buffer.from(
          qrCodeDataUrl.replace(/^data:image\/\w+;base64,/, ""),
          "base64"
        );

        const qrSize = 80;
        doc.image(qrImageBuffer, centerX - qrSize / 2, pageHeight - 150, {
          width: qrSize,
          height: qrSize,
        });

        doc
          .fontSize(9)
          .fillColor("#9CA3AF")
          .text("Scan to verify authenticity", 0, pageHeight - 55, {
            align: "center",
            width: pageWidth,
          });
      }

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
}

export function verifyQRData(qrData: string): {
  valid: boolean;
  data?: {
    participantId: string;
    participantName: string;
    eventName: string;
    eventDate: string;
    issueDate: string;
  };
  error?: string;
} {
  try {
    const parsed = JSON.parse(qrData);

    if (
      !parsed.participantId ||
      !parsed.participantName ||
      !parsed.eventName ||
      !parsed.eventDate ||
      !parsed.issueDate
    ) {
      return { valid: false, error: "Missing required fields" };
    }

    return { valid: true, data: parsed };
  } catch (error) {
    return { valid: false, error: "Invalid QR code data" };
  }
}
